# Responsive Portfolio Clay Doe
## [Watch it on youtube](https://youtu.be/BS6blX035NM)
### Responsive Portfolio Clay Doe
Clean and nice web portfolio, fully developed mobile first and responsive, for a designer or developer. It includes a Header, Home, About, Qualification, Services, Project in mind, Portfolio, Testimonial, Contact and Footer. And web animations in the home part.

Don't forget to join the channel for more videos like this.
[Bedimcode](https://www.youtube.com/c/Bedimcode)
